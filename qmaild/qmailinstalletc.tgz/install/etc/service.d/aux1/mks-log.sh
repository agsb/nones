#!/bin/sh
test -d /etc/service     || mkdir /etc/service
test -d /etc/service.d   || mkdir /etc/service.d
test -d /var/log || mkdir /var/log
for serv in $@ ; do 
test ! -d /etc/service.d/$serv && echo "error: service not found $serv " && exit 1
test -f /var/log/$serv && echo " error: file exists $serv " && exit 1
test -d /var/log/$serv && continue
mkdir /var/log/$serv
chown -R log. /var/log/$serv
ln -snf /var/log/$serv /etc/service.d/$serv/log/main 
done
