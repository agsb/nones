find ./*/env/ -type f -exec grep -H . \{\} \; | tr ':' ' '
