cat << EOF > .run
#!/bin/sh
export PATH=/usr/local/bin:\$PATH
exec 2>&1
exec setuidgid log multilog t '-status*' ./main '+status*' =./main/status
EOF
find ./*/log -maxdepth 0 -exec cp .run {}/run \; 
find ./*/log -maxdepth 0 -exec chmod 0755 {}/run \;
