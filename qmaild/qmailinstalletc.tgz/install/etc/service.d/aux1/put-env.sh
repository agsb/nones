while (true) do 	
read file content
test "$file" == "" && exit 0
echo "$content --> $file " 
echo "$content" > $file
done


