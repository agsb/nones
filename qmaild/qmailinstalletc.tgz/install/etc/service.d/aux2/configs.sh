cat << EOF > run
#!/bin/sh
exec chpst -ubin svlogd -tt \
  main/remote \
  main/main main/auth main/cron main/daemon main/debug main/ftp \
  main/kern main/local main/mail main/news main/syslog main/user \

EOF
chmod 755 run

cd main 

mkdir -p main auth cron daemon debug ftp 
mkdir -p kern local mail news syslog user
mkdir -p klog remote 

cat << EOF > main/config
s999999
n10
EOF

cat << EOF > klog/config
s999999
n10
EOF

cat << EOF > remote/config
s0
n10
U127.0.0.1:514
EOF

cat << EOF > auth/config
s999999
n5
-*
+auth.*
+authpriv.*
EOF

cat << EOF > cron/config
s999999
n5
-*
+cron.*
EOF

cat << EOF > daemon/config
s999999
n5
-*
+daemon.*
EOF

cat << EOF > debug/config
s999999
n5
-*
+*.debug*
EOF

cat << EOF > ftp/config
s999999
n5
-*
+ftp.*
EOF

cat << EOF > kern/config
s999999
n5
-*
+kern.*
EOF

cat << EOF > local/config
s999999
n5
-*
+local.*
EOF

cat << EOF > mail/config
s999999
n5
-*
+mail.*
EOF

cat << EOF > news/config
s999999
n5
-*
+news.*
EOF

cat << EOF > syslog/config
s999999
n5
-*
+syslog.*
EOF

cat << EOF > user/config
s999999
n5
-*
+user.*
EOF
