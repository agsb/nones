#!/bin/sh
PREFIX=

test -d /etc/service     || mkdir -p /etc/service
test -d /etc/service.d   || mkdir -p /etc/service.d
test -d /var/log/service || mkdir -p /var/log/service

for serv in $@ ; do 

test -d /var/log/service/$serv   || mkdir -p /var/log/service/$serv

test -d /etc/service.d/$serv/log || mkdir -p /etc/service.d/$serv/log

ln -snf /var/log/service/$serv /etc/service.d/$serv/log/main 

chown -R bin. /var/log/service/$serv

if [ ! -x /etc/service.d/$serv/log/run ]; then

cat << EOF > /etc/service.d/$serv/log/run
#!/bin/sh
exec 2>&1
exec chpst -ubin svlogd -r . -tt main
EOF
chmod 755 /etc/service.d/$serv/log/run

fi

if [ ! -r /etc/service.d/$serv/log/main/config ]; then
cat << EOF > /etc/service.d/$serv/log/main/config
s999999
n7
EOF

fi

done
